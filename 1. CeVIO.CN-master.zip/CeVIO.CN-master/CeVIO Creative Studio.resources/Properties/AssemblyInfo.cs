﻿using System.Resources;
using System.Reflection;

[assembly: AssemblyVersion("6.1.53.0")]
[assembly: AssemblyTitle("CeVIO Creative Studio")]
[assembly: AssemblyDescription(null)]
[assembly: AssemblyCompany("VOICeVIO")]
[assembly: AssemblyProduct("CeVIO.CN")]
[assembly: AssemblyCopyright("© 2018 CeVIO & VOICeVIO")]
[assembly: AssemblyTrademark("wdwxy12345@gmail.com")]
//[assembly: AssemblyFileVersion("6.1.14.1")]
[assembly: NeutralResourcesLanguage("ja-JP")]
[assembly: AssemblyCulture("ja-JP")]

