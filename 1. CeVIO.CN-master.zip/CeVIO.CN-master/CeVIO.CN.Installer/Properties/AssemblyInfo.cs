﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CeVIO.CN.Installer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("VOICeVIO")]
[assembly: AssemblyProduct("CeVIO.CN")]
[assembly: AssemblyCopyright("Copyright © VOICeVIO 2021-2022")]
[assembly: AssemblyTrademark("wdwxy12345@gmail.com")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("8f5c1711-28f2-4800-a9ed-19d468dc8d46")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.0.3.0")]
[assembly: AssemblyFileVersion("2.0.3.0")]
