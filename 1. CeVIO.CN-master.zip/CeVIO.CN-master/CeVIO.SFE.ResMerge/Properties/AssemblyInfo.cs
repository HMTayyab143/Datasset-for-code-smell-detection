﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CeVIO.SFE.ResMerge")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("VOICeVIO")]
[assembly: AssemblyProduct("CeVIO.CN")]
[assembly: AssemblyCopyright("Copyright © VOICeVIO 2019-2022")]
[assembly: AssemblyTrademark("wdwxy12345@gmail.com")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("498391c5-87fe-4f1c-b621-bf1ca6d719a4")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
